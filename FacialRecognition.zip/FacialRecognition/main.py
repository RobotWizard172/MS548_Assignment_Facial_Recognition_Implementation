# Jeff Koss
# Date: 07/23/2023
# Class: MS548
# Professor: Jill Coddington
# Assignment: Facial Recognition

#ETA: 3 hours 


from deepface import DeepFace
import matplotlib.pyplot as plt
import cv2

img_path = "D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 6\Homework\FacialRecognition\Face_db\Jeff\20230512_235532.jpg"

img = cv2.imread(img_path)

plt.imshow(img[:, :, ::-1])

demography = DeepFace.analyze(img_path)

demography